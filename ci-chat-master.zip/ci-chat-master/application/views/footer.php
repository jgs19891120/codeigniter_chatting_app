	<script src="assets/bs/jquery.min.js" type="text/javascript" charset="utf-8" async defer></script>
</body>
</html>