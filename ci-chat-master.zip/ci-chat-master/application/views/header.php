<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Login</title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/bs/css/apps.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/bs/css/bootstrap.min.css') ?>">
</head>
<body background="<?= base_url('assets/img/bg.jpg') ?>" style="background-size: cover">
	
